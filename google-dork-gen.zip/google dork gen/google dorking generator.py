print("1. config file       : \n2. database file     : \n3. directory listing :\n4. login page        :\n5. log file          : \n6. WordPress         : \n")

input1 = str (input("choisi une option : \n"))
              

if input1 == "1" :
    print("site: ext:xml | ext:conf | ext:cnf | ext:reg | ext:inf | ext:rdp | ext:cfg | ext:txt | ext:ora | ext:ini")


if input1 == "2" :
    print("site: ext:sql | ext:dbf | ext:mdb")


if input1 == "3":
    print("site: intitle:index.of")


if input1 == "4" :
    print("site: inurl:login | inurl:signin | intitle:Login | intitle: signin | inurl:auth")


if input1 == "5" :
    print("site: ext:xml | ext:conf | ext:cnf | ext:reg | ext:inf | ext:rdp | ext:cfg | ext:txt | ext:ora | ext:ini")


if input1 == "6" :
    print("site: inurl:wp- | inurl:wp-content | inurl:plugins | inurl:uploads | inurl:themes | inurl:download")


close = input("\n entre le réultat sur google ! \n appui sur entré pour quitter")