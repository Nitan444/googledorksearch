____EN____
-- Google Dorking Query Generator

This Python project generates Google Dorking queries based on specific options. Google Dorking is a technique used to find sensitive or specific information on websites using advanced queries.

-- Features

- Generates Google Dorking queries for different types of files and site elements.
- Options to search for configuration files, databases, directory listings, login pages, and WordPress-specific elements.

-- How to Use

1. Clone the repository or download the Python file.
2. Make sure you have Python installed on your machine.
3. Run the script using the following command:

   python google_dorking_generator.py



____FR____
-- Google Dorking Query Generator

Ce projet Python permet de générer des requêtes de Google Dorking basées sur des options spécifiques. Google Dorking est une technique utilisée pour trouver des informations sensibles ou spécifiques sur des sites web en utilisant des requêtes avancées.

-- Fonctionnalités

- Génération de requêtes Google Dorking pour différents types de fichiers et d'éléments de site.
- Options pour rechercher des fichiers de configuration, des bases de données, des listes de répertoires, des pages de connexion, et des éléments spécifiques à WordPress.

-- Comment utiliser

1. Clonez le dépôt ou téléchargez le fichier Python.
2. Assurez-vous d'avoir Python installé sur votre machine.
3. Exécutez le script en utilisant la commande suivante :

   python google_dorking_generator.py
